from flask import Blueprint, render_template, request, send_file
import os
import pandas as pd
from collections import defaultdict

bp = Blueprint('main', __name__)

@bp.route('/')
def home():
    return render_template('home.html')

@bp.route('/generate', methods=['POST'])
def generate():
    # Get the number of lessons
    num_lessons = int(request.form.get('num_lessons'))
    
    lessons = []
    hours = []
    
    # Collect lesson names and hours
    for i in range(1, num_lessons + 1):
        lesson_name = request.form.get(f'lesson_{i}')
        lesson_hours = int(request.form.get(f'hours_{i}'))
        
        lessons.append(lesson_name)
        hours.append(lesson_hours)
    
    # Total number of items (to be distributed across lessons)
    total_items = int(request.form.get('total_items'))
    total_hours = sum(hours)
    
    # Generate TOS using the input data
    output_path = generate_tos(lessons, hours, total_items, total_hours)
    
    # Pass the generated filename to the result page
    return render_template('result.html', file_url='tos_with_taxonomy.xlsx')

def generate_tos(lessons, hours, total_items, total_hours):
    # Ensure the 'generated' folder exists
    generated_folder = os.path.join(os.getcwd(), 'generated')
    if not os.path.exists(generated_folder):
        os.makedirs(generated_folder)
    
    data = []
    for i, lesson in enumerate(lessons):
        item_percentage = (hours[i] / total_hours) * 100
        num_items = round(total_items * (hours[i] / total_hours))
        bloom_items = distribute_bloom(num_items)
        item_placement = f"(I) {i*10+1}-{i*10+10}"
        data.append([lesson, hours[i], f"{item_percentage:.2f}%", num_items, *bloom_items.values(), item_placement])
    
    # Create a DataFrame to structure the data
    df = pd.DataFrame(data, columns=["Objectives/Content", "No. of Hours Taught", "Item Percentage", "No. of Items", "Knowledge", "Comprehension", "Application", "Item Placement"])
    
    # Write the file to the 'generated' folder
    output_path = os.path.join(generated_folder, 'tos_with_taxonomy.xlsx')
    df.to_excel(output_path, index=False)
    
    return output_path

def distribute_bloom(total_items):
    # Distribute items across Bloom's taxonomy levels
    bloom_items = defaultdict(int)
    bloom_items["Knowledge"] = round(total_items * 0.3)
    bloom_items["Comprehension"] = round(total_items * 0.3)
    bloom_items["Application"] = round(total_items * 0.4)
    
    return dict(bloom_items)

# Download route for the generated file
@bp.route('/download/<filename>')
def download(filename):
    # Construct the absolute path to the file in the 'generated' folder
    generated_folder = os.path.join(os.getcwd(), 'generated')
    file_path = os.path.join(generated_folder, filename)

    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    else:
        return "File not found", 404
