import pdfplumber
from docx import Document
import pandas as pd
from collections import defaultdict
import os

def parse_pdf(filepath):
    with pdfplumber.open(filepath) as pdf:
        text = ""
        for page in pdf.pages:
            text += page.extract_text()
        return extract_lessons_from_text(text)

def parse_docx(filepath):
    doc = Document(filepath)
    text = "\n".join([p.text for p in doc.paragraphs])
    return extract_lessons_from_text(text)

def parse_excel(filepath):
    df = pd.read_excel(filepath)
    lessons = df.iloc[:, 0].tolist()  # Assume lessons are in the first column
    hours = df.iloc[:, 1].tolist()  # Assume hours are in the second column
    return lessons, hours

def extract_lessons_from_text(text):
    lines = text.split("\n")
    lessons = [line.strip() for line in lines if line.strip()]
    hours = [0] * len(lessons)  # Default to 0 hours for each lesson
    return lessons, hours

def parse_files(filepaths):
    all_lessons = []
    all_hours = []
    for filepath in filepaths:
        if filepath.endswith(".pdf"):
            lessons, hours = parse_pdf(filepath)
        elif filepath.endswith(".docx"):
            lessons, hours = parse_docx(filepath)
        elif filepath.endswith(".xlsx"):
            lessons, hours = parse_excel(filepath)
        else:
            continue
        all_lessons.extend(lessons)
        all_hours.extend(hours)
    return all_lessons, all_hours

def generate_tos(filepath, hours, total_items, bloom_distribution):
    lessons, hours = parse_files([filepath]) if filepath else (["E-commerce Infrastructure", "The Internet and Web Part 1", "The Internet and Web Part 2"], [6, 5, 5])
    total_hours = sum(map(int, hours))
    
    # Ensure the 'generated' folder exists
    generated_folder = os.path.join(os.getcwd(), 'generated')
    if not os.path.exists(generated_folder):
        os.makedirs(generated_folder)
    
    data = []
    for i, lesson in enumerate(lessons):
        item_percentage = (int(hours[i]) / total_hours) * 100
        num_items = int(total_items * (int(hours[i]) / total_hours))
        bloom_items = distribute_bloom(num_items, bloom_distribution)
        item_placement = f"(I) {i*10+1}-{i*10+10}"
        data.append([lesson, hours[i], f"{item_percentage:.2f}%", num_items, *bloom_items.values(), item_placement])
    
    # Create a DataFrame to structure the data
    df = pd.DataFrame(data, columns=["Objectives/Content" "No. of Hours Taught", "Item Percentage", "No. of Items", "Knowledge", "Comprehension", "Application", "Item Placement"])
    
    # Add institutional header information at the top of the DataFrame
    header = [
        "Republic of the Philippines\nCAVITE STATE UNIVERSITY\nImus Campus\nCavite Civic Center Palico IV, Imus, Cavite\n",
        "🕿🖷 (046) 471-66-07 / (046) 471-67-70 / (046) 686-2349\nwww.cvsu.edu.ph\n\nDepartment of Computer Studies\n\n",
        "TABLE OF SPECIFICATIONS\n\nLearning Area: ITEC106 – Web System and Technologies 2\nNo. of Hours: {}\nNo. of Items: {}\n".format(total_hours, total_items),
        "🖵 Midterm 🖵 Finals 🖵 1st 🖵 2nd Sem./A.Y. 2023-2024\n"
    ]
    
    # Write institutional header and the DataFrame to the Excel file
    output_path = os.path.join(generated_folder, 'tos_with_taxonomy.xlsx')
    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        # Write header and DataFrame
        for idx, header_text in enumerate(header):
            pd.DataFrame([header_text]).to_excel(writer, sheet_name='TOS', startrow=idx, index=False, header=False)
        df.to_excel(writer, sheet_name='TOS', startrow=len(header), index=False)
    
    return output_path

def distribute_bloom(total_items, bloom_distribution):
    bloom_items = defaultdict(int)
    for level, percentage in bloom_distribution.items():
        bloom_items[level] = round(total_items * (percentage / 100))
    return dict(bloom_items)
