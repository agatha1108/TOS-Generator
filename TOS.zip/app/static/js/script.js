document.getElementById('num_lessons').addEventListener('input', function() {
    const numLessons = this.value;
    const container = document.getElementById('lessons-container');
    container.innerHTML = '';  // Clear existing inputs

    for (let i = 1; i <= numLessons; i++) {
        container.innerHTML += `
            <h5>Lesson ${i}</h5>
            <div class="form-group">
                <label for="lesson_${i}">Lesson Name:</label>
                <input type="text" class="form-control" id="lesson_${i}" name="lesson_${i}" required>
            </div>
            <div class="form-group">
                <label for="hours_${i}">No. of Hours:</label>
                <input type="number" class="form-control" id="hours_${i}" name="hours_${i}" required>
            </div>
        `;
    }
});
